#include <stdio.h>
#include <stdlib.h>


#define MAXVAL 100
#define NUMBER '0'


int getop(char []);
void push(double);
double pop(void);


int getch(void);
void ungetch(int);